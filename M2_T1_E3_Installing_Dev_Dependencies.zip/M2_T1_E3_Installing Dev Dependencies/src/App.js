import React from "react";

const App = () => {
  return (
    <>
      <h1>Welcome to React Parcel Micro App!</h1>
      <p>Hard to get more minimal.</p>
    </>
  );
};

export default App;
